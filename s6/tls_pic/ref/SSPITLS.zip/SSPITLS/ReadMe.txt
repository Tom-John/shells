SSPITLS.Dll is only 20k.

This Dll may be used in any way you wish - at your own risk. 
It has been tested with a gmail SMTPS session only although it should work when used to create an SSL session for an HTTPS session for example.

For a full description of the code
www.coastrd.com

Coast Research 2010